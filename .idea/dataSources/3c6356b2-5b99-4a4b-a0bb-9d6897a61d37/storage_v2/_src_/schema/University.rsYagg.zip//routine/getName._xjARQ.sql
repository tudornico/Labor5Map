create
    definer = root@localhost function getName(ID int) returns varchar(20) deterministic
BEGIN
declare resultName varchar(20);
    Select Name into resultName
        FROM Course
        where CourseId = ID;
return resultName;
end;

