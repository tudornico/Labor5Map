create
    definer = root@localhost function getString(atributeName varchar(20), TableName varchar(20),
                                                Objectcounter int) returns varchar(20) deterministic
Begin
    declare counter int;
    declare result varchar(20);
    set counter=1;
    ParsingTable: while counter<= 100
    DO


    SELECT atributeName into result
    From TableName
    where Objectcounter = @cursor;
    set @cursor=@cursor+1;
    END while ParsingTable;
    return result;

End;

