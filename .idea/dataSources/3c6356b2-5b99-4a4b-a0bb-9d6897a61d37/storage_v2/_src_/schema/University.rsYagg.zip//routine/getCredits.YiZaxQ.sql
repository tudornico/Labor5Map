create
    definer = root@localhost function getCredits(Id int) returns int deterministic
BEGIN
     declare credits int;
     SELECT Credits into credits
    FROM  Course
        where CourseId=Id;
     return credits;

end;

